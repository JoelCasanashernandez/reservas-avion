
var langEsp = ["RESERVA", "OFERTAS", "CONTACTO", "Reserva tus viajes", "Origen", "Destino", "Precio Máximo", "A partir de", "Fecha de salida", "Compañía", "Buscar", "Aerolinea", "Origen-Destino", "Horario", "Coste", "Reservar","Aerolinea", "Origen-Destino", "Horario", "Coste", "Contáctanos", "Dirección"];

var langEng = ["BOOKING", "OFFERS", "CONTACT", "Book your trips", "From", "To", "Maximum price", "starting from", "Departure date", "Company","Search", "Airline", "From-To", "Time", "Price", "Book", "Airline", "From-To", "Time", "Price", "Contact us", "Address"];

var langVal = ["RESERVA", "OFERTES", "CONTACTE", "Reserva els teus viages", "Orige", "Desti", "Cost maxim", "A partir de", "Data d'eixida", "Companyia", "Buscar", "Aerolinea", "Orige-Desti", "Horari", "Cost", "Reservar","Aerolinea", "Orige-Desti", "Horari", "Cost", "Contacta", "Direccio"];

var placeHolderEsp = ["Ida", "Tu nombre", "Tu correo", "Mensaje"];

var placeHolderEng = ["Going", "Your name", "Your email", "Message"];

var placeHolderVal = ["Anada", "El teu nom", "el teu correu", "Mensage"];